Maths Practice
=====
 * Author @ Daryl Howe 01/03/2020
 * Contact - howedaryl@hotmail.com


Description
============
'Maths Practice' is an Android application which tests and helps users practice basic arithmetic.

Instructions
============ 
Use the following link to install the application onto an Android mobile device.
* https://play.google.com/store/apps/details?id=com.DarylHoweDevs.MathsPractice

Maths Practice is a self driven project and was chosen as a way to learn about the Android framework and 
mobile application development.