package com.DarylHoweDevs.MathsPractice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.DarylHoweDevs.MathsPractice.R;

import java.util.ArrayList;
import java.util.Random;

public class Main2Activity extends AppCompatActivity {

    // declare variables

    Button button01;
    Button button02;
    Button button03;
    Button button04;

    Button playAgainButton;
    Button menuButton;

    int sumLimiter;

    int n1, n2, answer;
    int possibleAnswer01, possibleAnswer02, possibleAnswer03;

    TextView questionText;
    String question;

    int randomPossibleAnswer01;
    int randomPossibleAnswer02;
    int randomPossibleAnswer03;
    int randomPossibleAnswer04;

    int randombutton01;
    int randombutton02;
    int randombutton03;
    int randombutton04;

    int mode;

    int scoreCount=0;
    String scoreCountMessage = "Score Count: ";

    static int highScoreCount=0;
    String highScoreCountMessage = "High Score: ";

    TextView scoreCountText;
    TextView highScoreCountText;

    CountDownTimer countdownTimer;
    TextView countdownText;

    // create and Array List
    ArrayList<Button> buttonList = new ArrayList<>();
    ArrayList<Integer> possibleAnswersList = new ArrayList<>();

    Vibrator vibe;

    MediaPlayer tickSound;
    MediaPlayer correctAnswerSound;

    SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // get selected mode by user .ie + - x or /
        mode = MainActivity.getPracticeTypePressed();

        // get difficulty value level set by user on prior screen/activity
        sumLimiter = MainActivity.getSeekBarDifficultyLevel();


        button01 = (Button)findViewById(R.id.possibleAnswerButton01);
        button02 = (Button)findViewById(R.id.possibleAnswerButton02);
        button03 = (Button)findViewById(R.id.possibleAnswerButton03);
        button04 = (Button)findViewById(R.id.possibleAnswerButton04);

        scoreCountText = (TextView)findViewById(R.id.scoreCountText);
        scoreCountText.setText(scoreCountMessage + (scoreCount));

        highScoreCountText = (TextView)findViewById(R.id.highScoreCountText);
        highScoreCountText.setText(highScoreCountMessage + (highScoreCount));

        questionText = (TextView)findViewById(R.id.questionText);

        countdownText = (TextView)findViewById(R.id.countdownText);

        playAgainButton = (Button)findViewById(R.id.playAgainButton);
        playAgainButton.setAlpha(0);
        playAgainButton.setVisibility(View.INVISIBLE);

        sharedPreferences = getPreferences(MODE_PRIVATE);

        menuButton = (Button)findViewById(R.id.menuButton);

        tickSound = MediaPlayer.create(this, R.raw.clicks71);
        correctAnswerSound = MediaPlayer.create(this, R.raw.zings10);

        vibe = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);

        countdownTimer();
        generateQuestionAndAnswer();
    }

    /**
     * A method to generate a random question to present to the user.
     * Two random numbers generated between 1 and the sumLimiter bounds.
     * Depending on what mode type was selected a question and answer is created.
     */
    public void generateQuestionAndAnswer() {

        // create random number between 1 and (set difficulty level) * 2
        Random r1 = new Random();
        n1 = r1.nextInt(sumLimiter*2) +1;

        Random r2 = new Random();
        n2 = r2.nextInt(sumLimiter*2) + 1;

        // depending on what mode was selected create a question and answer
        // addition = 0
        // subtraction = 1
        // multiplication = 2
        // devision = 3

        if (mode == 0){

            // add n1 and n2 and set the question text
            answer = n1 + n2;
            question = n1 + "+" + n2 + "=";
            questionText.setText(question);

        } else if (mode == 1){

            // subtract n1 by n2 and set the question text
            answer = n1 - n2;
            question = Integer.toString(n1) + "-" + Integer.toString(n2) + "=";
            questionText.setText(question);

        } else if (mode == 2){

            // multiply n1 by n2 and set the question text
            answer = n1 * n2;
            question = n1 + "x" + n2 + "=";
            questionText.setText(question);

        } else if (mode == 3) {
            do{
                    // sumLimiter *10 to account for needing higher n1 value when dividing otherwise the amount of questions that can be asked will be limited
                    Random r14 = new Random();
                    n1 = r14.nextInt(sumLimiter * 10) + 1;

                    Random r15 = new Random();
                    n2 = r15.nextInt(sumLimiter*10) + 1;

                    // ensures first digit is always bigger than second, ensures only questions with no remainder are asked
                } while (n1 < n2 || n1%n2 !=0) ;

                // devide n1 by n2 and set the question text
                answer = n1 / n2;
                question = n1 + "/" + n2 + "=";
                questionText.setText(question);
        }

        createPossibleAnswers();

        addToButtonsAndPossibleAnswersLists();
    }

    /**
     * A method to generate 3 semi random other possible answers to display to the user.
     * The possible answer values is controlled to ensure it remains close to the actual answer, thus meaning the actual answer cannot be easily guessed.
     * If the possible answer generated is equal to the actual answer, another possible answer will be generated.
     */
    public void createPossibleAnswers(){
        // sets how far away the range of possible answers are from the actual answer
        int randomRange = 1;

        // if + - x mode selected
        if(mode == 0 || mode == 1 || mode == 2) {
            // loop ensures the possible answer created is not equal to the actual answer
            do {
                Random r3 = new Random();
                possibleAnswer01 = r3.nextInt((((answer + randomRange) - (answer - randomRange)) * 2)) + (answer - randomRange) + 1;
            } while (possibleAnswer01 == answer);

            do {
                do {
                    Random r4 = new Random();
                    possibleAnswer02 = r4.nextInt((((answer + randomRange) - (answer - randomRange)) * 2)) + (answer - randomRange) + 1;
                } while (possibleAnswer02 == answer);
            } while (possibleAnswer02 == possibleAnswer01);

            do {
                do {
                    Random r5 = new Random();
                    possibleAnswer03 = r5.nextInt((((answer + randomRange) - (answer - randomRange)) * 2)) + (answer - randomRange) + 1;
                } while (possibleAnswer03 == answer);
            } while (possibleAnswer03 == possibleAnswer01 || possibleAnswer03 == possibleAnswer02);
            // if division mode was selected
        } else {
            do {
                Random r3 = new Random();
                possibleAnswer01 = r3.nextInt((((answer + randomRange) - (answer - randomRange)) * 6)) + (answer - randomRange) + 1;

            } while (possibleAnswer01 == answer);

            do {
                do {
                    Random r4 = new Random();
                    possibleAnswer02 = r4.nextInt((((answer + randomRange) - (answer - randomRange)) * 6)) + (answer - randomRange) + 1;
                } while (possibleAnswer02 == answer);
            } while (possibleAnswer02 == possibleAnswer01);

            do {
                do {
                    Random r5 = new Random();
                    possibleAnswer03 = r5.nextInt((((answer + randomRange) - (answer - randomRange)) * 6)) + (answer - randomRange) + 1;
                } while (possibleAnswer03 == answer);
            } while (possibleAnswer03 == possibleAnswer01 || possibleAnswer03 == possibleAnswer02);
        }
    }

    /**
     * A method to add the possible answers + actual answer to UI buttons in a random order.
     */
    public void addToButtonsAndPossibleAnswersLists(){
        buttonList.add(button01);
        buttonList.add(button02);
        buttonList.add(button03);
        buttonList.add(button04);

        possibleAnswersList.add(answer);
        possibleAnswersList.add(possibleAnswer01);
        possibleAnswersList.add(possibleAnswer02);
        possibleAnswersList.add(possibleAnswer03);

       // Log.i("Entire List", Arrays.toString(possibleAnswersList.toArray()));

        // take a random answer from possible answer list. Note: this list also includes the actual answer
        Random r6 = new Random();
        randomPossibleAnswer01 = r6.nextInt(possibleAnswersList.size());

        // take a random button from button list
        Random r10 = new Random();
        randombutton01 = r10.nextInt(buttonList.size());

        // set the selected random button's text to the selected random possible answer
        buttonList.get(randombutton01).setText(Integer.toString(possibleAnswersList.get(randomPossibleAnswer01)));

        // remove the selected button button and possible answer from each of their respective lists
        possibleAnswersList.remove(randomPossibleAnswer01);
        buttonList.remove(randombutton01);



        //repeat of above but for possible answer 02
        Random r7 = new Random();
        randomPossibleAnswer02 = r7.nextInt(possibleAnswersList.size());

        Random r11 = new Random();
        randombutton02 = r11.nextInt(buttonList.size());

        buttonList.get(randombutton02).setText(Integer.toString(possibleAnswersList.get(randomPossibleAnswer02)));
        possibleAnswersList.remove(randomPossibleAnswer02);
        buttonList.remove(randombutton02);



        //repeat of above but for possible answer 03
        Random r8 = new Random();
        randomPossibleAnswer03 = r8.nextInt(possibleAnswersList.size());

        Random r12 = new Random();
        randombutton03 = r12.nextInt(buttonList.size());

        buttonList.get(randombutton03).setText(Integer.toString(possibleAnswersList.get(randomPossibleAnswer03)));
        possibleAnswersList.remove(randomPossibleAnswer03);
        buttonList.remove(randombutton03);



        //repeat of above but for possible answer 04
        Random r9 = new Random();
        randomPossibleAnswer04 = r9.nextInt(possibleAnswersList.size());

        Random r13 = new Random();
        randombutton04 = r13.nextInt(buttonList.size());

        buttonList.get(randombutton04).setText(Integer.toString(possibleAnswersList.get(randomPossibleAnswer04)));
        possibleAnswersList.remove(randomPossibleAnswer04);
        buttonList.remove(randombutton04);

        setTagOfCorrectButton();
    }

    /**
     * A method to set the tag of the correct answer button to 'Correct'
     */
    public void setTagOfCorrectButton(){

        // set the tag of the correct answer button to 'Correct'
        if(button01.getText().equals(Integer.toString(answer))){
            button01.setTag("Correct");
        }
        else if(button02.getText().equals(Integer.toString(answer))){
            button02.setTag("Correct");
        }
        else if(button03.getText().equals(Integer.toString(answer))){
            button03.setTag("Correct");
        }
        else if(button04.getText().equals(Integer.toString(answer))){
            button04.setTag("Correct");
        }
    }

    /**
     * A method to create and start the UI countdown timer.
     * When timer has finished the UI is updated to display the users score, the high score and options to play again or go to main menu
     */
    public void countdownTimer(){
        //main countdown timer, 30 seconds long
        countdownTimer = new CountDownTimer (30000, 1000){
            @Override
            public void onTick(long millisUntilFinished) {
                countdownText.setText("Time Left: " + Long.toString(millisUntilFinished/1000) + "s");
            }

            @Override
            public void onFinish() {
                final int animationDuration = 2000;

                // animate the elements on screen
                button01.setEnabled(false);
                button01.animate().alpha(0).setDuration(animationDuration);

                button02.setEnabled(false);
                button02.animate().alpha(0).setDuration(animationDuration-250);

                button03.setEnabled(false);
                button03.animate().alpha(0).setDuration(animationDuration-500);

                button04.setEnabled(false);
                button04.animate().alpha(0).setDuration(animationDuration-750);

                questionText.animate().alpha(0).setDuration(animationDuration);
                countdownText.animate().alpha(0).setDuration(animationDuration);

                float scaleValue = 2f;
                scoreCountText.animate().translationX(0).translationY(-650).scaleX(scaleValue).scaleY(scaleValue).rotation(720).setDuration(animationDuration+500);
                highScoreCountText.animate().translationX(0).translationY(-600).scaleX(scaleValue).scaleY(scaleValue).rotation(720).setDuration(animationDuration+500);

                menuButton.animate().translationYBy(760).setDuration(animationDuration+300);

                //let animation play out then make playAgainButton visible
                new CountDownTimer(2000, 1000){
                    @Override
                    public void onTick(long millisUntilFinished) {
                    }

                    @Override
                    public void onFinish() {
                        playAgainButton.setVisibility(View.VISIBLE);
                        playAgainButton.animate().alpha(1).setDuration(animationDuration);
                    }
                }.start();
            }
        }.start();
    }

    /**
     * A method to determine what action to taken depending on whether the user presses a correct or incorrect answer button
     */
    public void buttonPressed(View view){
        final Button button = (Button)view;

        // if the correct button has been pressed
        if(button.getTag().equals("Correct")){

            //disable button from being pressed again
            button.setEnabled(false);

            // play correct audio sample
            correctAnswerSound.start();

            button.animate().rotationBy(360).setDuration(500);

            // countdown ensures button remains disabled during the entire animation length
            countdownTimer = new CountDownTimer(500, 500) {
                    @Override
                    public void onTick(long millisUntilFinished) {
                    }

                    @Override
                    public void onFinish() {
                        //re-enable button
                        button.setEnabled(true);
                    }
                }.start();

            // add 1 to score
            scoreCount = scoreCount + 1;

            //update high score if score count is above the highscore value
            if (scoreCount > highScoreCount) {
                highScoreCount = scoreCount;
                highScoreCountText.setText(highScoreCountMessage + highScoreCount);

                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putInt("High Score Value", highScoreCount);
                editor.apply();
                // editor.commit();
            }

            //reset button tags
            button01.setTag("ResetTag");
            button02.setTag("ResetTag");
            button03.setTag("ResetTag");
            button04.setTag("ResetTag");

            //start entire again with new question, answer, possible answers
            generateQuestionAndAnswer();

            //if wrong answer button pressed
        }   else {
            vibe.vibrate(100);
            scoreCount = scoreCount-2;
        }

        // stop score count going below 0. ie it cannot be minus
        if(scoreCount <= 0){
            scoreCount = 0;
        }

        // set score count text
        scoreCountText.setText(scoreCountMessage + scoreCount);
    }

    /**
     * A method to open 'MainActivity' ie menu UI
     * @param view
     */
    public void mainMenuButtonPressed(View view) {

        //stop the countdown timer
        countdownTimer.cancel();

        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    /**
     * A method to reload 'Main2Activity' under the same conditions as before. ie same mode and difficulty level
     */
    public void playAgainButtonPressed(View view){

        int animationDuration01 = 500;
        scoreCountText.animate().translationXBy(-600).rotation(540).setDuration(animationDuration01);
        highScoreCountText.animate().translationXBy(600).rotation(540).setDuration(animationDuration01);

        new CountDownTimer(600, 600){
            @Override
            public void onTick(long millisUntilFinished) {
            }

            @Override
            public void onFinish() {
                  openActivity2();
            }
        }.start();

    }

    /**
     * A method to load 'Main2Activity'
     */
    public void openActivity2() {
        Intent intent = new Intent(this, Main2Activity.class);
        startActivity(intent);
    }
}
