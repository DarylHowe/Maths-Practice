package com.DarylHoweDevs.MathsPractice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import com.DarylHoweDevs.MathsPractice.R;

public class MainActivity extends AppCompatActivity {

    // Declare variables

    ImageView testIconView;
    TextView testYourselfText;

    TextView selectionText;
    TextView additionText;
    TextView subtractionText;
    TextView multiplicationText;
    TextView divisionText;

    TextView countdownText01;
    int animationDuration = 1500;

    MediaPlayer tickSound;

    static int mode;
    static int sumLimiter02 =5;

    SeekBar levelDifficultySeekBar;
    TextView levelDifficultyText;

    int maxLevelDifficultyValue = 20;
    int initialLevelDifficultyValue = 5;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Element variables are linked with on screen UI elements

        countdownText01 = (TextView)findViewById(R.id.countdownText);
        countdownText01.setAlpha(0);

        tickSound = MediaPlayer.create(this, R.raw.clicks71);

        testIconView = (ImageView) findViewById(R.id.testIcon);
        testYourselfText = (TextView) findViewById(R.id.testYourselfText);

        selectionText = (TextView) findViewById(R.id.selectionText);
        additionText  = (TextView) findViewById(R.id.additionText);
        subtractionText = (TextView) findViewById(R.id.subtractionText);
        multiplicationText = (TextView) findViewById(R.id.mulitplicationText);
        divisionText = (TextView) findViewById(R.id.divisionText);

        selectionText.setVisibility(View.INVISIBLE);
        additionText.setVisibility(View.INVISIBLE);
        subtractionText.setVisibility(View.INVISIBLE);
        multiplicationText.setVisibility(View.INVISIBLE);
        divisionText.setVisibility(View.INVISIBLE);

        levelDifficultySeekBar = (SeekBar)findViewById(R.id.levelDifficultySeekBar);
        levelDifficultyText = (TextView)findViewById((R.id.levelDifficultyText));
        levelDifficultyText.setText("Difficulty Level: " + initialLevelDifficultyValue);
        levelDifficultySeekBar.setVisibility(View.INVISIBLE);
        levelDifficultyText.setVisibility(View.INVISIBLE);

        levelDifficultySeekBar();
    }

    /**
     * A method to update the UI when the 'Maths Practive' icon or text is pressed
     */
    public void testYourselfButtonPressed(View view) {
            // play tick sound
            tickSound.start();

            // animation
            testIconView.animate().translationX(600).rotation(360).alpha(0).setDuration(animationDuration-700);
            testYourselfText.animate().translationX(-600).rotation(-360).alpha(0).setDuration(animationDuration-700);

            // setup next screen
            selectionText.setVisibility(View.VISIBLE);
            additionText.setVisibility(View.VISIBLE);
            subtractionText.setVisibility(View.VISIBLE);
            multiplicationText.setVisibility(View.VISIBLE);
            divisionText.setVisibility(View.VISIBLE);

            levelDifficultySeekBar.setVisibility(View.VISIBLE);
            levelDifficultyText.setVisibility(View.VISIBLE);
        }

    /**
     *  A method to set the game mode type depending on which mode the user selects. The UI is updated after a selection has been made.
     *  0 = addition, 1 = subtraction, 2 = multiplication, 3 = division
     */
    public void practiceTypePressed(View view){
        TextView textView = (TextView)view;

        // play tick sound
        tickSound.start();


        // set mode value depending on pressed selection
        if(textView.getTag().equals("addition")){
            mode = 0;
        }
        else if(textView.getTag().equals("subtraction")){
            mode = 1;
        }
        else if(textView.getTag().equals("multiplication")){
            mode = 2;
        }
        else if(textView.getTag().equals("division")){
            mode = 3;
        }

        // setup next screen
        selectionText.setVisibility(View.INVISIBLE);
        additionText.setVisibility(View.INVISIBLE);
        subtractionText.setVisibility(View.INVISIBLE);
        multiplicationText.setVisibility(View.INVISIBLE);
        divisionText.setVisibility(View.INVISIBLE);
        levelDifficultySeekBar.setVisibility(View.INVISIBLE);
        levelDifficultyText.setVisibility(View.INVISIBLE);

        // show countdown text and start countdown01 method
        countdownText01.setAlpha(1);
        countdown();
    }

    /**
     * A method to start a 4 second countdown to to represent a "3..2..1..Go!"
     * This countdown is set to be viewed on the UI.
     * Activity 2 is opened when this countdown has ended.
     */
    public void countdown(){

        new CountDownTimer(4000, 1000){
            @Override
            public void onTick(long millisUntilFinished) {

                // set countdown text to time in seconds. /1000 to convert ms to second
                countdownText01.setText(Long.toString(millisUntilFinished/1000));

                if(millisUntilFinished<=1000){
                    countdownText01.setText("Go!");
                    countdownText01.animate().rotation(720).alpha(0).setDuration(1000);
                }
            }
            @Override
            public void onFinish() {
                openActivity2();
            }
        }.start();
    }

    /**
     * a method to return what game mode was pressed.
     * @return an int which represents what game mode was chosen by user. 0 = addition, 1 = subtraction, 2 = multiplication, 3 = division
     */
    public static int getPracticeTypePressed(){
        return mode;
    }

    /**
     * A method to allow the user to set the level difficulty via an on screen seek bar.
     * Level difficult is stored as static int 'sumLimiter02'
     */
    public void levelDifficultySeekBar(){

        // set max and initial difficulty level, -2 value ensures 0 and 1 difficulty levels are not available
        levelDifficultySeekBar.setMax(maxLevelDifficultyValue-2);
        levelDifficultySeekBar.setProgress(initialLevelDifficultyValue);

        levelDifficultySeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                levelDifficultyText.setText("Difficulty Level: " + (progress+2));
                sumLimiter02 = progress+2;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

    }

    /**
     * a method to return what difficulty level was entered
     * @return a static int that represents the level difficulty set by the user
     */
    public static int getSeekBarDifficultyLevel(){
        return  sumLimiter02;
    }

    /**
     * A method to open Main2Activity
     */
    public void openActivity2() {
        Intent intent = new Intent(this, Main2Activity.class);
        startActivity(intent);
    }

}
